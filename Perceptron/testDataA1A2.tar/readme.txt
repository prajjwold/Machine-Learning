Two sample data files, one for each assignment.
The training data is the training data that will be used
but the test data may change.

cubeData.txt - a simple 3 imput 3 output logic circuit formated as
required by the assigment.

irisData.txt - the iris training data formated as required by the
assigment.
